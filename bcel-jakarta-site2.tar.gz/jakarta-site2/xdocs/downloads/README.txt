The downloads.xml file in this directory are processed by the stylesheets in this
directory to generate cgi and html pages for downloading the commons components
listed in the downloads.xml file.

Whenever a commons component has a new release, the downloads.xml file must be
updated.
