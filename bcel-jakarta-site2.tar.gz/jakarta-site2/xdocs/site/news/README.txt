Do NOT add news to these documents. 

New news content is now generated from news.xml in the top-level directory.

Please see http://jakarta.apache.org/site/news/index.html#How%20To%20Add%20News%20(Committers)
for more details.
