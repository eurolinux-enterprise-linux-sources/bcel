$Id: README.txt 192969 2005-06-22 18:20:43Z dlr $

The files in this directory are for getting you up to speed
quickly if you choose to use this system to render your website.

Do *not* run Ant in this my-project directory without first making a
copy of that directory to the same location as the jakarta/site/
repository is checked out.  A command like the following will create
such a copy (minus the SVN administrative directories):

svn export \
  https://svn.apache.org/repos/asf/jakarta/site/examples/my-project \
  ../../my-project

You can find out more information by going to this website:

http://jakarta.apache.org/site/jakarta-site2.html

Thanks!
