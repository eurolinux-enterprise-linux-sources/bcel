$Id: README.txt 390955 2006-04-03 05:20:59Z bayard $

Read ./docs/site/jakarta-site2.html or ./docs/README.txt for details on how to build the Jakarta site.

They may also be found at http://jakarta.apache.org/site/jakarta-site2.html and 
http://jakarta.apache.org/README.txt.

NOTE: 
  The HTML and CGI files are generated from XML source files. 
  Please don't update the HTML files directly; update the XML file, and run the ant build.

See above references for further information

When committing files, please ensure both the XML and any generated HTML files are checked back in.

[The target directory does not need to be checked in; it contains intermediate files only]
